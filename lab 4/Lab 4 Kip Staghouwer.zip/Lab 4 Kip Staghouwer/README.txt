checks:

Declaration of variables
initialization of variables
double declartions (within scope ofcourse)
type mismatches within expressions(and terms)
type mismatches in assignments
wether the identifier of a functioncall is a function
if the number of arguments in a functioncall is correct
if the types in a functionscall are correct.
