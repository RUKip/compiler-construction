#ifndef HEADER_FILE
#define HEADER_FILE
void initLexer(char *filename);
void showLine();
void finalizeLexer();
#endif
