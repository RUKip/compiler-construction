#ifndef HEADER_FILE
#define HEADER_FILE
int value;
#endif