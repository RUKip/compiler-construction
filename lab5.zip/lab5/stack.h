#ifndef STACK_H
#define STACK_H

char* pop();
void push(char* c);
void initStack();
void freeStack();

#endif
