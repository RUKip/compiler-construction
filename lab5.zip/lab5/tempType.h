#ifndef TEMPTYPE_H
#define TEMPTYPE_H

typedef struct tempType {
  int temp; //value of temp //cOutput
  int type;  
}tempType;

#endif